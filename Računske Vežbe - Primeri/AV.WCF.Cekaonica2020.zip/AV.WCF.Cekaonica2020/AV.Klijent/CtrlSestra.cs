﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AV.Klijent.ServiceReferenceCekaonica;

namespace AV.Klijent
{
    public partial class CtrlSestra : AVCtrl
    {
        public CtrlSestra()
        {
            InitializeComponent();
        }
        public CtrlSestra(Osoblje logovani, CekaonicaCallbackHadler cch, CekaonicaClient prox)
            : this()
        {
            Logovan = logovani;
            Handler = cch;
            proxy = prox;

            cmbLekar.DisplayMember = "Ime";
            cmbLekar.DataSource = proxy.GetLekari();
        }

        private void btnProsledi_Click(object sender, EventArgs e)
        {
            if (cmbLekar.SelectedValue == null)
                return;
            Osoblje l = cmbLekar.SelectedValue as Osoblje;
            proxy.PosaljiUCekaonicuAsync(l.UiD, txtPacijent.Text, Logovan.UiD);
        }
    }
}
