﻿using AV.WCF.Cekaonica.Data;
using System;
using System.ServiceModel;

namespace AV.WCF.Cekaonica
{
    public interface ICekaonicaCallback
    {
        [OperationContract(IsOneWay = true)]
        void PregledajPacijenta(Guid id, string pacijent);

        [OperationContract(IsOneWay = true)]
        void Promena(CekaonicaStatus status);
    }
}