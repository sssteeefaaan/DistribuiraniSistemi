﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AV.Klijent.ServiceReferenceCekaonica;

namespace AV.Klijent
{
    public partial class CtrlMonitor : AVCtrl
    {
        Osoblje lekar;
        public CtrlMonitor()
        {
            InitializeComponent();
        }
        public CtrlMonitor(CekaonicaCallbackHadler cch, CekaonicaClient prox)
            : this()
        {
            Handler = cch;
            proxy = prox;

            cmbLekar.DisplayMember = "Ime";
            cmbLekar.DataSource = proxy.GetLekari();

            Handler.PromenaHandler += Handler_PromenaHandler;
        }

        private void Handler_PromenaHandler(CekaonicaStatus promena)
        {
            if (promena.LekarUiD != lekar.UiD)
                return;
            switch(promena.Status)
            {
                case (Status.CekaNaPregled):
                    AppendText(richTextBox, promena.Pacijent, Color.Green);
                    break;
                case (Status.KodLekara):
                    AppendText(richTextBox, promena.Pacijent, Color.Blue);
                    break;
                case (Status.Pregledan):
                    AppendText(richTextBox, promena.Pacijent, Color.Red);
                    break;
            }

        }

        private void cmbLekar_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbLekar.SelectedValue == null)
                return;
            Osoblje l = cmbLekar.SelectedValue as Osoblje;
            if (l == null)
                return;
            lekar = l;

            proxy.SledecaPromenaAsync(lekar.UiD);
        }
    }
}
