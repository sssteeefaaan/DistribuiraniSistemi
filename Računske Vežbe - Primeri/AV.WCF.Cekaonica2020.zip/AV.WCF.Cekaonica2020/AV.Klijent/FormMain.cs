﻿using AV.Klijent.ServiceReferenceCekaonica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AV.Klijent
{
    public partial class FormMain : Form
    {
        CekaonicaClient proxy;
        Osoblje logovani;

        CekaonicaCallbackHadler cch;

        public FormMain()
        {
            InitializeComponent();

            cch = new CekaonicaCallbackHadler();

            InstanceContext instanceContext = new InstanceContext(cch);

            proxy = new CekaonicaClient(instanceContext);
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            errorProvider.SetError(btnLogIn, "");
            logovani = proxy.LogIn(txtIme.Text, txtPrezime.Text);
            if (logovani == null)
            {
                errorProvider.SetError(btnLogIn, "Pokusajte ponovo!");
                return;
            }
            this.Controls.Clear();
            if(logovani.Lekar)
            {
                CtrlLekar lekar = new CtrlLekar(logovani, cch, proxy);
                this.Controls.Add(lekar);
            }
            else
            {
                CtrlSestra sestra = new CtrlSestra(logovani, cch, proxy);
                this.Controls.Add(sestra);
            }
        }

        private void btnMonitor_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            CtrlMonitor mon = new CtrlMonitor(cch, proxy);
            this.Controls.Add(mon);
        }
    }
}
