﻿namespace AV.Klijent
{
    partial class CtrlMonitor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlp = new System.Windows.Forms.TableLayoutPanel();
            this.lblLekar = new System.Windows.Forms.Label();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.cmbLekar = new System.Windows.Forms.ComboBox();
            this.tlp.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlp
            // 
            this.tlp.ColumnCount = 2;
            this.tlp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlp.Controls.Add(this.lblLekar, 0, 0);
            this.tlp.Controls.Add(this.richTextBox, 0, 1);
            this.tlp.Controls.Add(this.cmbLekar, 1, 0);
            this.tlp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlp.Location = new System.Drawing.Point(0, 0);
            this.tlp.Name = "tlp";
            this.tlp.RowCount = 2;
            this.tlp.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tlp.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlp.Size = new System.Drawing.Size(400, 600);
            this.tlp.TabIndex = 0;
            // 
            // lblLekar
            // 
            this.lblLekar.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblLekar.AutoSize = true;
            this.lblLekar.Location = new System.Drawing.Point(3, 7);
            this.lblLekar.Name = "lblLekar";
            this.lblLekar.Size = new System.Drawing.Size(34, 13);
            this.lblLekar.TabIndex = 0;
            this.lblLekar.Text = "Lekar";
            // 
            // richTextBox
            // 
            this.tlp.SetColumnSpan(this.richTextBox, 2);
            this.richTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox.Location = new System.Drawing.Point(3, 30);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.Size = new System.Drawing.Size(394, 567);
            this.richTextBox.TabIndex = 1;
            this.richTextBox.Text = "";
            // 
            // cmbLekar
            // 
            this.cmbLekar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbLekar.FormattingEnabled = true;
            this.cmbLekar.Location = new System.Drawing.Point(43, 3);
            this.cmbLekar.Name = "cmbLekar";
            this.cmbLekar.Size = new System.Drawing.Size(354, 21);
            this.cmbLekar.TabIndex = 2;
            this.cmbLekar.SelectedValueChanged += new System.EventHandler(this.cmbLekar_SelectedValueChanged);
            // 
            // CtrlMonitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tlp);
            this.Name = "CtrlMonitor";
            this.Size = new System.Drawing.Size(400, 600);
            this.tlp.ResumeLayout(false);
            this.tlp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlp;
        private System.Windows.Forms.Label lblLekar;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.ComboBox cmbLekar;
    }
}
