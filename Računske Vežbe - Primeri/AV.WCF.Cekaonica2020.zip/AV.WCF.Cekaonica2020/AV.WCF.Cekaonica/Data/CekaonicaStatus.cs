﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace AV.WCF.Cekaonica.Data
{
    [DataContract]
    [Serializable]
    public class CekaonicaStatus
    {
        [DataMember]
        public Guid LekarUiD { get; set; }
        [DataMember]
        public string Pacijent { get; set; }
        [DataMember]
        public Status Status { get; set; }
    }
}