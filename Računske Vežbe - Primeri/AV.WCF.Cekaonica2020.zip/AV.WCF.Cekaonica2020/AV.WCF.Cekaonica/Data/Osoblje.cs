﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace AV.WCF.Cekaonica.Data
{
    [DataContract]
    [Serializable]
    public class Osoblje
    {
        [DataMember]
        public Guid UiD { get; set; }
        [DataMember]
        public string Ime { get; set; }
        [DataMember]
        public string Prezime { get; set; }
        [DataMember]
        public bool Lekar { get; set; }

        public Osoblje()
        {
            UiD = Guid.NewGuid();
        }

        public string Display
        {
            get { return Ime + " " + Prezime; }
        }
    }
}