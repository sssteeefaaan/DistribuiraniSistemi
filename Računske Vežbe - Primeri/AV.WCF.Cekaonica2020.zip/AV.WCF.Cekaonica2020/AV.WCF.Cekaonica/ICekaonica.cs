﻿using AV.WCF.Cekaonica.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace AV.WCF.Cekaonica
{   //http://Microsoft.ServiceModel.Samples
    [ServiceContract(Namespace = "http://AV.WCF.Cekaonica",
        SessionMode = SessionMode.Required,
        CallbackContract = typeof(ICekaonicaCallback))]
    public interface ICekaonica
    {
        [OperationContract]
        List<Osoblje> GetLekari();

        [OperationContract]
        Osoblje LogIn(string ime, string prezime);
        
        [OperationContract]
        void PosaljiUCekaonicu(Guid lekar, string pacijent, Guid mr);
        //[OperationContract]
        //void StigaoNaPregled(Guid lekar, string pacijent, Guid mr);
        [OperationContract]
        void Pregledan(Guid lekar, string pacijent);


        [OperationContract(IsOneWay = true)]
        void SledeciZaPregled(Guid id);

        [OperationContract(IsOneWay = true)]
        void SledecaPromena(Guid lekar);
    }
}
