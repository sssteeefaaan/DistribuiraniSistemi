﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AV.Klijent.ServiceReferenceCekaonica;

namespace AV.Klijent
{
    public partial class AVCtrl : UserControl
    {
        protected CekaonicaClient proxy;
        public Osoblje Logovan { get; internal set; }
        public CekaonicaCallbackHadler Handler { get; set; }

        public AVCtrl()
        {
            InitializeComponent();
        }

        public void DisplayMessage(TextBox tbx, string message)
        {
            if (tbx.InvokeRequired)
            {
                tbx.Invoke(new MethodInvoker(delegate () 
                { DisplayMessage(tbx, message); }));
            }
            else
            {
                tbx.Text = message;
            }
        }

        public void AppendText(RichTextBox box, string text, Color color, bool addNewLine = true)
        {
            if (box.InvokeRequired)
            {
                box.Invoke(new MethodInvoker(delegate () { AppendText(box, text, color, addNewLine); }));
            }
            else
            {
                box.SuspendLayout();
                Color old = box.SelectionColor;
                box.SelectionColor = color;
                box.AppendText(addNewLine
                    ? $"{text}{Environment.NewLine}"
                    : text);
                box.ScrollToCaret();
                box.SelectionColor = old;
                box.ResumeLayout();
            }
        }
    }
}
