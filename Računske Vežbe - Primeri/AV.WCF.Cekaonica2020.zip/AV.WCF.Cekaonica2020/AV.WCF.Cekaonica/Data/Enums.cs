﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AV.WCF.Cekaonica.Data
{
    [Serializable]
    public enum Status
    {
        CekaNaPregled,
        KodLekara,
        Pregledan
    }
}