import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Prijava extends Remote{
	
	String vratiPrijavljeneIspite() throws RemoteException;
	boolean prijaviIspit(String ispit) throws RemoteException;
	boolean ponistiIspit(String ispit) throws RemoteException;
}