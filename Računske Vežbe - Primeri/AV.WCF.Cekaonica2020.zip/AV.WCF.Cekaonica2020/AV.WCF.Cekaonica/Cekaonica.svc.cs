﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using AV.WCF.Cekaonica.Data;
using System.Threading;

namespace AV.WCF.Cekaonica
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class Cekaonica : ICekaonica
    {
        public Cekaonica()
        {
        }

        public List<Osoblje> GetLekari()
        {
            return Store.Instance.osoblje.Where(x => x.Lekar).ToList();
        }

        public Osoblje LogIn(string ime, string prezime)
        {
            Osoblje o = Store.Instance.osoblje
                .Where(x => x.Ime.Equals(ime))
                .FirstOrDefault();

            if(o!=null && o.Lekar)
            {
                if (!Store.Instance.odgovoriNa.ContainsKey(o.UiD))
                    Store.Instance.odgovoriNa.Add(o.UiD, new List<ICekaonicaCallback>());
                if (!Store.Instance.odgovoriNa[o.UiD].Contains(Callback))
                    Store.Instance.odgovoriNa[o.UiD].Add(Callback);
            }

            return o;
        }

        public void PosaljiUCekaonicu(Guid lekar, string pacijent, Guid mr)
        {
            if (!Store.Instance.cekajuNaPregled.ContainsKey(lekar))
                Store.Instance.cekajuNaPregled.Add(lekar, new Queue<string>());
            Store.Instance.cekajuNaPregled[lekar].Enqueue(pacijent);

            if (!Store.Instance.poslednjaPromena.ContainsKey(lekar))
                Store.Instance.poslednjaPromena.Add(lekar, new CekaonicaStatus()
                {
                    LekarUiD = lekar,
                    Pacijent = pacijent,
                    Status = Status.CekaNaPregled
                });
            else
                Store.Instance.poslednjaPromena[lekar] = new CekaonicaStatus()
                {
                    LekarUiD = lekar,
                    Pacijent = pacijent,
                    Status = Status.CekaNaPregled
                };

            if (!Store.Instance.naPregledu.ContainsKey(lekar))
                Store.Instance.naPregledu.Add(lekar, null);
            if(Store.Instance.naPregledu[lekar]==null)
            {
                ProslediSledeceg(lekar);
            }
        }

        private void ProslediSledeceg(Guid lekar)
        {
            if (!Store.Instance.cekajuNaPregled.ContainsKey(lekar))
                Store.Instance.cekajuNaPregled.Add(lekar, new Queue<string>());
            if (Store.Instance.cekajuNaPregled[lekar].Count == 0)
                return;
            string sledeci = Store.Instance.cekajuNaPregled[lekar].Dequeue();

            if (!Store.Instance.poslednjaPromena.ContainsKey(lekar))
                Store.Instance.poslednjaPromena.Add(lekar, new CekaonicaStatus()
                {
                    LekarUiD = lekar,
                    Pacijent = sledeci,
                    Status = Status.KodLekara
                });
            else
                Store.Instance.poslednjaPromena[lekar] = new CekaonicaStatus()
                {
                    LekarUiD = lekar,
                    Pacijent = sledeci,
                    Status = Status.KodLekara
                };

            if (!Store.Instance.naPregledu.ContainsKey(lekar))
                Store.Instance.naPregledu.Add(lekar, null);
            Store.Instance.naPregledu[lekar] = sledeci;

            Store.Instance.PregledajSledeceg(lekar, sledeci);
            Store.Instance.ProslediPromenuZaLekara(lekar);
        }

        public void Pregledan(Guid lekar, string pacijent)
        {
            if (!string.IsNullOrEmpty(pacijent))
            {
                if (!Store.Instance.pregledani.ContainsKey(lekar))
                    Store.Instance.pregledani.Add(lekar, new List<string>());
                Store.Instance.pregledani[lekar].Add(pacijent);

                if (!Store.Instance.poslednjaPromena.ContainsKey(lekar))
                    Store.Instance.poslednjaPromena.Add(lekar, new CekaonicaStatus()
                    {
                        LekarUiD = lekar,
                        Pacijent = pacijent,
                        Status = Status.Pregledan
                    });
                else
                    Store.Instance.poslednjaPromena[lekar] = new CekaonicaStatus()
                    {
                        LekarUiD = lekar,
                        Pacijent = pacijent,
                        Status = Status.Pregledan
                    };

                Store.Instance.ProslediPromenuZaLekara(lekar);

                Store.Instance.naPregledu[lekar] = null;
            }

            ProslediSledeceg(lekar);
        }

        public void SledeciZaPregled(Guid lekar)
        {
            if (Store.Instance.naPregledu.ContainsKey(lekar) && string.IsNullOrEmpty(Store.Instance.naPregledu[lekar]))
                ProslediSledeceg(lekar);
        }

        public void SledecaPromena(Guid lekar)
        {
            if (!Store.Instance.odgovoriNa.ContainsKey(lekar))
                Store.Instance.odgovoriNa.Add(lekar, new List<ICekaonicaCallback>());
            if (!Store.Instance.odgovoriNa[lekar].Contains(Callback))
                Store.Instance.odgovoriNa[lekar].Add(Callback);

            if (Store.Instance.poslednjaPromena.ContainsKey(lekar))
                Store.Instance.ProslediPromenuZaLekara(lekar);
        }

        ICekaonicaCallback Callback
        {
            get
            {
                return OperationContext.Current
                    .GetCallbackChannel<ICekaonicaCallback>();
            }
        }
    }
}
