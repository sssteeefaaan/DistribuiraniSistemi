﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AV.Klijent.ServiceReferenceCekaonica;

namespace AV.Klijent
{
    public partial class CtrlLekar : AVCtrl
    {
        public CtrlLekar()
        {
            InitializeComponent();
        }

        public CtrlLekar(Osoblje logovani, CekaonicaCallbackHadler cch, CekaonicaClient prox)
            :this()
        {
            Logovan = logovani;
            Handler = cch;
            proxy = prox;

            Handler.PregledajPacijentaHandler += Handler_PregledajPacijentaHandler;
        }

        private void Handler_PregledajPacijentaHandler(Guid id, string pacijent)
        {
            if (!Logovan.UiD.Equals(id))
                return;
            DisplayMessage(txtPacijent, pacijent);
        }

        private void btnPregledan_Click(object sender, EventArgs e)
        {
            proxy.PregledanAsync(Logovan.UiD, txtPacijent.Text);
            txtPacijent.Text = string.Empty;
            proxy.SledeciZaPregledAsync(Logovan.UiD);
        }

        private void btnSledeci_Click(object sender, EventArgs e)
        {
            txtPacijent.Text = string.Empty;
            proxy.SledeciZaPregledAsync(Logovan.UiD);
        }
    }
}
