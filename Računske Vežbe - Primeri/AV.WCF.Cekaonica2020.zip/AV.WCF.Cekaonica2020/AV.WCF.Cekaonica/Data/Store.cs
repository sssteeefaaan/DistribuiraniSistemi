﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;

namespace AV.WCF.Cekaonica.Data
{
    public class Store
    {
        public Dictionary<Guid, Queue<string>> cekajuNaPregled;
        public Dictionary<Guid, List<string>> pregledani;
        public Dictionary<Guid, string> naPregledu;
        public Dictionary<Guid, CekaonicaStatus> poslednjaPromena;

        public Dictionary<Guid, List<ICekaonicaCallback>> odgovoriNa;

        public List<Osoblje> osoblje;

        private static Store instance = null;

        private static object locker = true;
        
        public static Store Instance
        {
            get
            {
                lock (locker)
                {
                    if (instance == null)
                        instance = new Store();
                }
                return instance;
            }
        }

        protected Store()
        {
            cekajuNaPregled = new Dictionary<Guid, Queue<string>>();
            pregledani = new Dictionary<Guid, List<string>>();
            naPregledu = new Dictionary<Guid, string>();
            poslednjaPromena = new Dictionary<Guid, CekaonicaStatus>();

            odgovoriNa = new Dictionary<Guid, List<ICekaonicaCallback>>();

            osoblje = new List<Osoblje>(){
                new Osoblje()
                {
                    Ime = "Bosa",
                    Lekar = false,
                },
                new Osoblje()
                {
                    Ime = "Nata",
                    Lekar = false,
                },
                new Osoblje()
                {
                    Ime = "Mile",
                    Lekar = true,
                },
                new Osoblje()
                {
                    Ime = "Zika",
                    Lekar = true,
                },
                new Osoblje()
                {
                    Ime = "Anka",
                    Lekar = true,
                },
                new Osoblje()
                {
                    Ime = "Dragana",
                    Lekar = true,
                }
            };
        }

        internal void ProslediPromenuZaLekara(Guid lekar)
        {
            if (odgovoriNa.ContainsKey(lekar))
                odgovoriNa[lekar]
                    .ForEach(callback =>
                        callback.Promena(Store.Instance.poslednjaPromena[lekar])
                    );
        }

        internal void PregledajSledeceg(Guid lekar, string sledeci)
        {
            if (odgovoriNa.ContainsKey(lekar))
                odgovoriNa[lekar]
                    .ForEach(callback =>
                        callback.PregledajPacijenta(lekar, sledeci)
                    );
        }
    }
}