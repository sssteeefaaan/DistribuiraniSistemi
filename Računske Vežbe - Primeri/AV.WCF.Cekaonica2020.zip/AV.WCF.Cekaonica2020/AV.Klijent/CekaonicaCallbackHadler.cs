﻿using AV.Klijent.ServiceReferenceCekaonica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace AV.Klijent
{
    public delegate void delPregledajPacijenta(Guid id, string pacijent);
    public delegate void delPromena(CekaonicaStatus promena);

    public class CekaonicaCallbackHadler : ICekaonicaCallback
    {
        public event delPregledajPacijenta PregledajPacijentaHandler;
        public event delPromena PromenaHandler;
        public void PregledajPacijenta(Guid id, string pacijent)
        {
            if (PregledajPacijentaHandler != null)
                PregledajPacijentaHandler(id, pacijent);
        }

        public void Promena([MessageParameter(Name = "promena")] CekaonicaStatus promena1)
        {
            if (PromenaHandler != null)
                PromenaHandler(promena1);
        }
    }
}
