import java.io.Serializable;

public class KlijentAukcije implements Serializable{
	
	public String id;
	String ime;
	String prezime;
	
	public KlijentAukcije(String klijentAukcijeID, String ime, String prezime){
		
		this.id = klijentAukcijeID;
		this.ime = ime;
		this.prezime = prezime;
	}
}